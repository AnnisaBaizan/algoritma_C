// tugas2a.c
#include <stdio.h>
#include <string.h>

// Struktur untuk menyimpan data pegawai
struct Pegawai {
    char nip[20];      // Nomor induk pegawai
    char nama[50];     // Nama pegawai
    char alamat[100];  // Alamat pegawai
    char no_hp[20];    // Nomor HP pegawai
    char jabatan[30];  // Jabatan pegawai
    char golongan[3];  // Golongan pegawai (D1, D2, D3)
    int gaji_pokok;    // Gaji pokok berdasarkan golongan
};

// Fungsi untuk mengambil gaji pokok berdasarkan golongan
int getGajiPokok(char golongan[]) {
    if (strcmp(golongan, "D1") == 0)
        return 2500000;    // Gaji golongan D1
    else if (strcmp(golongan, "D2") == 0)
        return 2000000;    // Gaji golongan D2
    else if (strcmp(golongan, "D3") == 0)
        return 1500000;    // Gaji golongan D3
    else
        return 0;          // Golongan tidak valid
}

int main() {
    struct Pegawai pegawai;        // Variabel struct pegawai
    FILE *fp;                      // Pointer untuk file

    // Input data pegawai
    printf("=== Input Data Pegawai ===\n");
    printf("NIP        : ");
    gets(pegawai.nip);       // Input NIP
    printf("Nama       : ");
    gets(pegawai.nama);      // Input nama
    printf("Alamat     : ");
    gets(pegawai.alamat);    // Input alamat
    printf("No HP      : ");
    gets(pegawai.no_hp);     // Input nomor HP
    printf("Jabatan    : ");
    gets(pegawai.jabatan);   // Input jabatan
    printf("Golongan   : ");
    gets(pegawai.golongan);  // Input golongan

    pegawai.gaji_pokok = getGajiPokok(pegawai.golongan); // Hitung gaji pokok

    // Simpan data ke file
    fp = fopen("data_pegawai.txt", "w");         // Buka file untuk ditulis
    if (fp == NULL) {
        printf("Gagal membuka file!\n");        // Gagal membuka file
        return 1;
    }

    // Simpan data ke file per baris
    fprintf(fp, "%s\n", pegawai.nip);
    fprintf(fp, "%s\n", pegawai.nama);
    fprintf(fp, "%s\n", pegawai.alamat);
    fprintf(fp, "%s\n", pegawai.no_hp); 
    fprintf(fp, "%s\n", pegawai.jabatan);
    fprintf(fp, "%s\n", pegawai.golongan);
    fprintf(fp, "%d\n", pegawai.gaji_pokok);

    fclose(fp);    // Tutup file

    // Tampilkan ringkasan
    printf("\nData berhasil disimpan!\n");
    printf("Gaji Pokok : Rp%d\n", pegawai.gaji_pokok);

    return 0;
}
